import { LightningElement , api } from 'lwc';
import { OmniscriptBaseMixin } from 'omnistudio/omniscriptBaseMixin';
import  writeXlsxFile from 'c/writeExcelFile';
//import  { dataRowConst } from './acfrDownloadExcelConst';



export default class AcfrDownloadExcel extends OmniscriptBaseMixin(LightningElement) {
  datatableDefinitions;
  rowDefinitions;
  columnDefinitions;
  dataTableRows = [];

  @api formId;
  fileName = 'QFR.xlsx';
  //formId = "a2Y9h0000000fsnEAA"; fileName= 'QFR.xlsx';
  //formId = "a2Y9h0000000KMxEAM"; fileName= 'HCCare.xlsx';
  //formId = "a2Y9h0000000FqHEAU" fileName= 'ResiCare.xlsx';
  //formId = "a2Y9h0000000KMyEAM"; fileName = 'FoodNutriCost.xlsx';
  
  async download() {
      this.generateData();
      this.writeExcel();
  }

  async connectedCallback() {
      await this.getRecordData();
  }

  async getRecordData() {
      let args = {
          formId: this.formId
        };

      let options = {};
      let remoteCallParams = {
        input: JSON.stringify(args),
        sClassName: 'AcfrCustomDatatableController',
        sMethodName: 'getDatatableDefinitionForForm',
        options: JSON.stringify(options)
      }

      let { result, error } = await this.omniRemoteCall(remoteCallParams, false);
      this.datatableDefinitions = result.datatableDefinition;
      console.log('Datatable retrived '+JSON.stringify(this.datatableDefinitions));
      this.rowDefinitions = this.datatableDefinitions.rowDefinitions;
      this.columnDefinitions = this.datatableDefinitions.columnDefinitions;
      
    }

    
    
    async generateData(){
        let rowDefinationtIds = [];
        let rowDefinationSubParentIds = [];
        const subAssetPad = '    ';
        
        this.rowDefinitions.forEach((row) => { 
          rowDefinationtIds.push(row.id);
        });
        let categoryHeader = [];

        this.rowDefinitions.forEach((rowDef) => { 
          let rowOfColumns = [];

            //generate category headers from the rowDefination category
            if(!categoryHeader.includes(rowDef.category))
            {
              let categoryHeading = [];
              categoryHeader.push(rowDef.category);
              categoryHeading.push({value:rowDef.category, fontWeight: 'bold', fontSize:16, backgroundColor:'#D6EAF8'});
              this.columnDefinitions.forEach((colDef) => {
                categoryHeading.push({value:'', fontWeight: 'bold', fontSize:16, backgroundColor:'#D6EAF8'});
              });
              this.dataTableRows.push(categoryHeading);
            }
            
            //GL code indentention based on the ParentRow
            if(rowDefinationtIds.includes(rowDef.parentRowId))
            {
              rowDefinationSubParentIds.push(rowDef.id);
              if(rowDefinationSubParentIds.includes(rowDef.parentRowId)){
                rowOfColumns.push({value:subAssetPad+subAssetPad+rowDef.name});
              }else{
                rowOfColumns.push({value:rowDef.name});
              }
            }else{
              if(rowDef.name.includes('Total')){
                rowOfColumns.push({value:rowDef.name,fontWeight: 'bold',});
              }else{
                rowOfColumns.push({value:rowDef.name});
              }
            }

            this.columnDefinitions.forEach((col) => {
              col.data.forEach((dataRow) => {
                if(dataRow.rowDefinitionId == rowDef.id){
                  let elementValue ;
                  if(rowDef.type == 'Currency'){
                    elementValue = {value:dataRow.value,type: Number, format: '$#,##0.00'};
                  }else if(rowDef.type == 'Percentage'){
                    elementValue = {value:dataRow.value,type: Number, format: '0.00%'};
                  }else{
                    elementValue = {value:dataRow.value};
                  }
                  rowOfColumns.push(elementValue);
                }
              });
            });

            this.dataTableRows.push(rowOfColumns);
        });
        console.log('dataTableRows:'+JSON.stringify(this.dataTableRows));

        //Creating header rows from the columnDefinations
        let headerRow = [{value:''}];        
        this.columnDefinitions.forEach((col) => {
          let headerElement = {
            value: col.name,
            fontWeight: 'bold'
          };
          headerRow.push(headerElement);
        });

        this.dataTableRows.splice(0,0,headerRow);
  }


  async writeExcel(){
    await writeXlsxFile(this.dataTableRows, {
      fileName: this.fileName
    });
  }
}